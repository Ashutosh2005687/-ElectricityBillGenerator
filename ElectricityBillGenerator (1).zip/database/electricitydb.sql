CREATE DATABASE IF NOT EXISTS electricitydb;
USE electricitydb;

CREATE TABLE IF NOT EXISTS customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS bills (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    units INT,
    amount DOUBLE,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);