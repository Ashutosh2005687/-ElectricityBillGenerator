# Electricity Bill Generator

## Description
This is a simple GUI-based Java application to calculate electricity bills based on unit consumption.

## Technologies Used
- Java Swing for GUI
- MySQL for database
- JDBC for database connectivity

## Setup Instructions
1. Import `electricitydb.sql` into your MySQL database.
2. Update database credentials in `DBConnection.java` if needed.
3. Compile and run `Main.java` using any Java IDE or command line.