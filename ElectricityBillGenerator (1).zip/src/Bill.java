package src;

public class Bill {
    private int customerId;
    private int units;
    private double amount;

    public Bill(int customerId, int units, double amount) {
        this.customerId = customerId;
        this.units = units;
        this.amount = amount;
    }

    public double calculateAmount() {
        if (units <= 100) return units * 5;
        else if (units <= 200) return (100 * 5) + (units - 100) * 7;
        else return (100 * 5) + (100 * 7) + (units - 200) * 10;
    }
}