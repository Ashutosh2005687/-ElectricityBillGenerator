package src;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Electricity Bill Generator");
        JLabel label = new JLabel("Enter Units:");
        JTextField field = new JTextField();
        JButton button = new JButton("Generate Bill");
        JTextArea area = new JTextArea();

        label.setBounds(20, 20, 100, 30);
        field.setBounds(120, 20, 100, 30);
        button.setBounds(80, 70, 150, 30);
        area.setBounds(20, 120, 250, 100);

        frame.add(label);
        frame.add(field);
        frame.add(button);
        frame.add(area);
        frame.setSize(300, 300);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int units = Integer.parseInt(field.getText());
                Bill bill = new Bill(1, units, 0);
                double amount = bill.calculateAmount();
                area.setText("Units: " + units + "\nTotal Amount: Rs. " + amount);
            }
        });
    }
}